# CASEFLOW — Intelligent Pre-Consultation Patient Case-Taking System

A small academic Flask + SQLite prototype based on the supplied project synopsis.

## Features
- Seven-stage patient intake form with progress bar and required-field validation
- Patient-reported symptoms, duration, severity, history, medications and allergies
- Simple safety prompt for reported breathing difficulty
- Automatic structured case record
- Demo clinician login, case dashboard, case detail and status updates
- SQLite database created automatically

## Requirements
- Python 3.11 or newer
- VS Code (recommended) or another code editor
- Internet only for the optional Google Fonts stylesheet; the app itself runs locally

## Run on Windows (VS Code)
1. Install Python and VS Code.
2. Extract this ZIP file.
3. Open the extracted `CaseFlow` folder in VS Code.
4. Open **Terminal → New Terminal**.
5. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt and run:

   ```bat
   .venv\Scripts\activate.bat
   ```

6. Install packages:

   ```powershell
   python -m pip install -r requirements.txt
   ```

7. Start the app:

   ```powershell
   python app.py
   ```

8. Open this address in your browser:

   `http://127.0.0.1:5000`

## Demo workflow
1. Select **Start patient intake** and submit fictional test data.
2. Open **Doctor portal**.
3. Demo login:
   - Username: `doctor`
   - Password: `CaseFlow123!`
4. Open the submitted case and change its status to Reviewed or Follow-up.

## Database
The SQLite database is created automatically at `instance/caseflow.db` after the first run. To reset the demo data, stop the server and delete that database file; it will be recreated on next start.

## Project structure
```text
CaseFlow/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── intake.html
│   ├── submitted.html
│   ├── doctor_login.html
│   ├── dashboard.html
│   └── case_detail.html
└── static/
    ├── style.css
    └── intake.js
```

## Important academic and safety limitations
This is a classroom demonstration, not a production healthcare system. Use fictional/demo data only. It has not undergone clinical, privacy, security, or regulatory validation. The demo doctor password is intentionally visible in this README and must never be reused in a real deployment. Do not expose the Flask development server to the public internet. Before any real-world use, the system would need professional security engineering, access controls, encryption, consent and retention policies, audit logging, backups, and review for applicable health-data laws. It does not diagnose or recommend treatment.
