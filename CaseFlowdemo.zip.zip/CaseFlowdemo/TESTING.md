# CASEFLOW — Test plan for project demonstration

Use fictional values only. Perform these tests in the browser after starting the app.

| Test ID | Action | Expected result |
|---|---|---|
| TC01 | Open `/` | Home page and project description appear |
| TC02 | Click Patient intake | Seven-step form opens |
| TC03 | Click Next with required fields empty | Browser asks for required information |
| TC04 | Enter fictional details and move through steps | Progress bar advances through seven steps |
| TC05 | Select Yes for breathing difficulty | Urgent-care warning is displayed |
| TC06 | Submit all required fields and consent checkbox | Submission confirmation and case reference appear |
| TC07 | Open Doctor portal and enter demo credentials | Doctor dashboard opens |
| TC08 | Open the submitted case | Structured patient case summary appears |
| TC09 | Change status to Reviewed | Updated status appears on dashboard |
| TC10 | Log out and revisit dashboard | User is redirected to doctor login |

## Suggested viva explanation
- **Frontend:** HTML creates the pages, CSS styles them, and JavaScript controls the seven-step form and progress bar.
- **Backend:** Flask handles routes, validates submitted fields, creates case records, and checks clinician sessions.
- **Database:** SQLite stores each case; Flask-SQLAlchemy maps Python model fields to database columns.
- **Case summary:** The doctor detail page displays the stored patient answers in organized sections.
- **Safety:** The application only collects and organizes patient-entered information. It does not generate a diagnosis.

## Scope note
The current version uses a single demo clinician account and does not implement patient accounts, email verification, role administration, production-grade audit trails, or real AI. These can be listed as future enhancements rather than claimed as completed features.
